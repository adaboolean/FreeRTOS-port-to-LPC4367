#ifndef __RELOC_IRQ_TABLE_H__
#define __RELOC_IRQ_TABLE_H__

void relocIrqTable(void);


#endif
