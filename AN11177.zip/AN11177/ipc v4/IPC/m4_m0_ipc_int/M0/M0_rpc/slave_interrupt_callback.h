
#ifndef __M0_INT_CBACK_H__
#define __M4_INT_CBACK_H__

// external function which is called by the M0 within the interrupt context
void slaveInterruptCallback(void);

#endif

