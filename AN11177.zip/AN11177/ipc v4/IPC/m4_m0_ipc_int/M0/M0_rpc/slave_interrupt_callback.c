#include <stdint.h>
#include "type.h"
#include "ipc_int.h"
#include "slave_interrupt_callback.h"


/* command function skeleton  */
/* fill with your own code as needed */
void slaveInterruptCallback(void) { 

	return;

}


