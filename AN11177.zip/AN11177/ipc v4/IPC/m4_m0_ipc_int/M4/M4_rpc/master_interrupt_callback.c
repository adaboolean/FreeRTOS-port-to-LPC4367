#include <stdint.h>
#include "type.h"
#include "ipc_int.h"



/* command function skeleton  */
/* fill with your own code as needed */
void masterInterruptCallback(void) { 

	return;

}


