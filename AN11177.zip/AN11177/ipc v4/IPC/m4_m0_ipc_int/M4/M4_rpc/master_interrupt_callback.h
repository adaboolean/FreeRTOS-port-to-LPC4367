
#ifndef __M4_INT_CBACK_H__
#define __M4_INT_CBACK_H__

// external function which is called by the M4 within the interrupt context
void masterInterruptCallback(void);

#endif

