#ifndef __M0_IPC_MSG_H 
#define __M0_IPC_MSG_H

/* messages the slave shall get */
enum ipcSlaveMsg_tag {

	CMD_SLAVE_NONE = 0,
	CMD_SLAVE_BLINK
		
};

#endif
