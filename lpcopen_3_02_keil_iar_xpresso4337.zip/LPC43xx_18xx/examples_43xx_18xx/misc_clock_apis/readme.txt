Clock API's example

Example description
This example demonstrates the use of Clock APIs to control the CGU settings.  This example uses UART
console to print the outputs.

Special connection requirements
There are no special connection requirements for this example.







