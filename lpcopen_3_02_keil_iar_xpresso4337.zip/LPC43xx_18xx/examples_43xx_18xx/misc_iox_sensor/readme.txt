I2C IO Expansion device, Temperature sensor, IMU Demo example

Example description
This example demonstrates an IO expansion using I2C to control and read GPIO's
It will read the temperature value from the LM74A, and print it
to the LCD. It will turn ON/OFF LEDs connected IO Expansion, based on the
Joystick input. Every direction of joystick press will toggle one LED
Bosch IMU Sensor chip ID register will be read and printed on the LCD screen.

Special connection requirements
LPCXpresso General purpose shield board must be connected to the LPCXpresso v3 base
board.
 






