GPDMA Speed test example

Example description
This example benchmarks the data transfer speed of gpdma against cpu based transfer
function memcpy.

UART needs to be setup prior to running the example as the example produces the output
to the UART console.

Special connection requirements
There are no special connection requirements for this example.
 






