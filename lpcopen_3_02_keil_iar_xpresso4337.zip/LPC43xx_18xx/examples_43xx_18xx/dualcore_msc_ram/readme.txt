This file contains a USB MSC RAM example using USB ROM Drivers.

Example description
The example shows how to use USBD ROM stack to creates a USB MSC example
that uses RAM.

Special connection requirements
Connect the USB cable between micro connector on board and to a host.
The example exposes part of internal SRAM as storage space. 







