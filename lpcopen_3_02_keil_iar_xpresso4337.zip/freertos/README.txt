
This includes un-modified version V7.5.3 of the core FreeRTOS files, with the
demos removed from the source tree to save space.

The original files can be downloaded at:
http://www.freertos.org

Information on FreeRTOS licensing is located in the freertos/license.txt file
or go to the website.

 Copyright (C) 1989, 1991 Free Software Foundation, Inc.
                       59 Temple Place, Suite 330, Boston, MA  02111-1307  USA







